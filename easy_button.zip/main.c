#include <stdio.h>
#include <string.h>
#include "ebtn.h"
#include "windows.h"

extern int example_test(void);
extern int example_user(void);

int main(void)
{
    // example_test();
    example_user();
    return 0;
}
